import polygraphy.config

__version__ = "0.48.1"
