import csv
from pathlib import Path

import numpy as np
import utils.gpt_token_encoder as encoder


def get_tokenizer(vocab_file=None, bpe_file=None):
    cur_folder = Path(__file__).parent
    vocab_file = vocab_file if vocab_file is not None else cur_folder / "gpt2-vocab.json"
    bpe_file = bpe_file if bpe_file is not None else cur_folder / "gpt2-merges.txt"

    tokenizer = encoder.get_encoder(str(vocab_file), str(bpe_file))

    return tokenizer


def to_word_list_format(word_dict):
    tokenizer = get_tokenizer()

    flat_ids = []
    offsets = []
    for word_dict_item in word_dict:
        item_flat_ids = []
        item_offsets = []

        if isinstance(word_dict_item[0], bytes):
            word_dict_item = [word_dict_item[0].decode()]

        words = list(csv.reader(word_dict_item))[0]
        for word in words:
            ids = tokenizer.encode(word)

            if len(ids) == 0:
                continue

            item_flat_ids += ids
            item_offsets.append(len(ids))

        flat_ids.append(np.array(item_flat_ids))
        offsets.append(np.cumsum(np.array(item_offsets)))

    pad_to = max(1, max(len(ids) for ids in flat_ids))

    for i, (ids, offs) in enumerate(zip(flat_ids, offsets)):
        flat_ids[i] = np.pad(ids, (0, pad_to - len(ids)), constant_values=0)
        offsets[i] = np.pad(offs, (0, pad_to - len(offs)), constant_values=-1)

    return np.array([flat_ids, offsets], dtype="int32").transpose((1, 0, 2))
