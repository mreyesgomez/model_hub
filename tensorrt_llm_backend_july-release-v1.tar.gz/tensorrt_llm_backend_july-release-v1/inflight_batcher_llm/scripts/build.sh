#!/bin/bash
set -x
apt-get update
apt-get install -y --no-install-recommends rapidjson-dev

BUILD_DIR=$(dirname $0)/../build
mkdir $BUILD_DIR
BUILD_DIR=$(cd -- "$BUILD_DIR" && pwd)
cd $BUILD_DIR
cmake -DCMAKE_INSTALL_PREFIX:PATH=`pwd`/install \
      -DTRT_LIB_DIR=/usr/local/TensorRT-9.0.0.2/targets/x86_64-linux-gnu/lib \
      -DTRT_INCLUDE_DIR=/usr/local/TensorRT-9.0.0.2/include \
      ..
make install
